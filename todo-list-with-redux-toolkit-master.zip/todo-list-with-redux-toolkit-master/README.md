# TO-DO LIST USING REDUX TOOLKIT

In this project a created a to-do list by using Redux Toolkit

## used Technologies

In the project I used:

### React 

Main library 

### React Hooks

useSelector hook: accepts a function, and returns us the data based on that function.
useDispatch hook: able to dispatch any action to the store by simply adding an action as an argument to the new variable

### Redux Toolkit

An Easier Way to Set Up Redux. You can configure the global store and create both actions and reducers in a more streamlined manner.

### Bootstrap

### CSS